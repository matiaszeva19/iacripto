// Este archivo ha sido eliminado ya que el componente CryptoSelector no se utiliza más.
// La selección de criptomonedas ahora se realiza exclusivamente a través del buscador.
